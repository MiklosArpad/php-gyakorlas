$(document).ready(function(){
    
    //kosárhoz ad
    $('.addcart').click(function(){
        let id = $(this).data('id');
        //console.log(id);
        $.ajax({
            url : 'php/addtocart.php',
            method : 'POST',
            data: {id : id},
            success: function(){
                alert("Kosárhoz adva.");
            },
            error: function(){
                alert("Nem sikerült a kosárhoz adni!");
            }
        });
    });//VÉGE kosárhoz ad
    
    //termék törlése a kosárból
    $(".delete-product").click(function(){
	let id = $(this).data('id');
	//console.log("katt",id);
	$.ajax({
	    url: 'php/deleteproduct.php',
	    method: 'POST',
	    data: {delete : id},
	    success: function(){
		//oldal frissítése
		location.reload();
	    },
	    error: function(){
		
	    }
	});
	
    });
    
    
    //kosár ürítése
    
    
});//ready



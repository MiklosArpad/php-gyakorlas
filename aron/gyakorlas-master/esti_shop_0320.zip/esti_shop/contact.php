<?php
    echo file_get_contents("html/header.html");
    echo file_get_contents("html/footer.html");
        